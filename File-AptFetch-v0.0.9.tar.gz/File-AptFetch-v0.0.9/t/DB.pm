# $Id: DB.pm 344 2009-02-28 03:35:15Z whynot $

# use version 0.50; our $VERSION = qv |0.0.1|;

package DB;

sub get_fork_TTY {
    xterm_get_fork_TTY;
}

1;
